﻿年糕 Niangao P0 / PLACEHOLDER

双击 Niangao-P0.exe。无需安装 Godot 或 Blender。Windows 10/11 x64；需要 OpenGL 3.3 驱动。
拖动猫咪移动；右键/F3：调试；T：置顶；H：隐藏；Esc：保存退出；托盘：恢复/隐藏/退出。

重要验证状态：
42 项基础测试通过；X11 点击/穿透/拖动/位置恢复通过。
Windows exe 在 Wine 渲染和退出通过；Wine 透明区域点击测试失败。
Windows 10/11 原生测试未执行，不宣称已经验证完整鼠标穿透或 DPI/热拔。
详见 docs/validation.md、docs/windows-validation.md。

Windows 原生测试（会暂时移动鼠标，-ResetPosition 会备份并在结束时恢复配置）：
powershell -File tools/acceptance-windows.ps1 -Exe ./Niangao-P0.exe -ResetPosition

用户配置：%APPDATA%/Godot/app_userdata/Niangao P0/config.json
当前猫咪是程序几何占位模型；五个非 idle 动画、真实长毛和家园尚未实现。
真实年糕以用户提供的照片为准。

引擎与第三方许可见 docs/GODOT-LICENSE.txt 和 docs/GODOT-COPYRIGHT.txt。
